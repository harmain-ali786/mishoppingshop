import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative bg-gradient-to-r from-muted to-background py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Welcome to <span className="text-accent">Haseebshope</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            Discover premium quality products at unbeatable prices. Your trusted online shopping destination for
            everything you need.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Shop Now
            </Button>
            <Button variant="outline" size="lg">
              View Collections
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
