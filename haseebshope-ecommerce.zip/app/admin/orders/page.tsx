import { OrderManagement } from "@/components/admin/order-management"
import { AdminLayout } from "@/components/admin/admin-layout"

export default function AdminOrdersPage() {
  return (
    <AdminLayout>
      <OrderManagement />
    </AdminLayout>
  )
}
