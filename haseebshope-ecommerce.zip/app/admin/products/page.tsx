import { ProductManagement } from "@/components/admin/product-management"
import { AdminLayout } from "@/components/admin/admin-layout"

export default function AdminProductsPage() {
  return (
    <AdminLayout>
      <ProductManagement />
    </AdminLayout>
  )
}
